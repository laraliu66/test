package co.sltech.com.enums;

public enum OperationDataType {

	INSERT(1, "INSERT"), UPDATE(2, "UPDATE"), CANCEL(3, "CANCEL");

	private int num;
	private String type;
	

	private OperationDataType(int num, String type) {
		this.num = num;
		this.type = type;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
