package co.sltech.com.vo;

import co.sltech.com.enums.OperationDataType;
import co.sltech.com.enums.OperationTradeType;

public class Transactions {
	private Integer TransactionId;
	private Integer TradeId;
	private Integer Version;
	private String SecurityCode;
	private Integer Quantity;
	private OperationDataType dataType;
	private OperationTradeType tradeType;

	public Transactions(Integer transactionId, Integer tradeId, Integer version, String securityCode, Integer quantity,
			OperationDataType dataType, OperationTradeType tradeType) {
		super();
		TransactionId = transactionId;
		TradeId = tradeId;
		Version = version;
		SecurityCode = securityCode;
		Quantity = quantity;
		this.dataType = dataType;
		this.tradeType = tradeType;
	}

	public Integer getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(Integer transactionId) {
		TransactionId = transactionId;
	}

	public Integer getTradeId() {
		return TradeId;
	}

	public void setTradeId(Integer tradeId) {
		TradeId = tradeId;
	}

	public Integer getVersion() {
		return Version;
	}

	public void setVersion(Integer version) {
		Version = version;
	}

	public String getSecurityCode() {
		return SecurityCode;
	}

	public void setSecurityCode(String securityCode) {
		SecurityCode = securityCode;
	}

	public Integer getQuantity() {
		return Quantity;
	}

	public void setQuantity(Integer quantity) {
		Quantity = quantity;
	}

	public OperationDataType getDataType() {
		return dataType;
	}

	public void setDataType(OperationDataType dataType) {
		this.dataType = dataType;
	}

	public OperationTradeType getTradeType() {
		return tradeType;
	}

	public void setTradeType(OperationTradeType tradeType) {
		this.tradeType = tradeType;
	}

}
