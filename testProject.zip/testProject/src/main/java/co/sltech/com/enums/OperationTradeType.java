package co.sltech.com.enums;

public enum OperationTradeType {
	BUY(1, "Buy"), SELL(-1, "Sell");

	private int flag;
	private String type;

	private OperationTradeType(int flag, String type) {
		this.flag = flag;
		this.type = type;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
