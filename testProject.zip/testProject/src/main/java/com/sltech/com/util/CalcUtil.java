package com.sltech.com.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import co.sltech.com.enums.OperationDataType;
import co.sltech.com.vo.Transactions;

public class CalcUtil {

	// ������Դ
	private static List<Transactions> list = new ArrayList<Transactions>();

	// ����tradeId����������
	private static Map<Integer, List<Transactions>> tradeIdGroup = new HashMap<Integer, List<Transactions>>();

	// ����tradeId����������
	private static Map<Integer, Map<String, List<Transactions>>> securityCodeGroup = new HashMap<Integer, Map<String, List<Transactions>>>();

	// ���ս��
	private static Map<String, Integer> result = new HashMap<String, Integer>();

	// ��������
	public static void addData(Transactions tran) {
		list.add(tran);
	}

	// ����tradeId����
	private static void groupByTradeId() {
		tradeIdGroup = list.stream().collect(Collectors.groupingBy(Transactions::getTradeId));
	}

	// ����Version���򣬸���SecurityCode����
	private static void groupBySecurityCode() {
		for (Entry<Integer, List<Transactions>> entry : tradeIdGroup.entrySet()) {
			Map<String, List<Transactions>> group = entry.getValue().stream()
					.collect(Collectors.groupingBy(Transactions::getSecurityCode));
			securityCodeGroup.put(entry.getKey(), group);
		}
	}

	// ����Quantity
	public static Map<String, Integer> calcResult() {
		groupByTradeId();
		groupBySecurityCode();

		for (Entry<Integer, Map<String, List<Transactions>>> entry : securityCodeGroup.entrySet()) {
			Map<String, List<Transactions>> tempMap = entry.getValue();
			// ɸѡ��cancel������
			for (Entry<String, List<Transactions>> codeEntry : tempMap.entrySet()) {
				String code = codeEntry.getKey();
				List<Transactions> codeList = codeEntry.getValue();
				for (Transactions tran : codeList) {
					if (tran.getDataType().getNum() == 3) {
						List<Transactions> temp = new ArrayList<Transactions>();
						tran.setQuantity(0);
						tran.setDataType((OperationDataType.INSERT));
						temp.add(tran);
						tempMap.put(code, temp);
						break;
					}
				}
			}

			// ɸѡ��update������
			for (Entry<String, List<Transactions>> codeEntry : tempMap.entrySet()) {
				String code = codeEntry.getKey();
				List<Transactions> codeList = codeEntry.getValue();
				for (Transactions tran : codeList) {
					if (tran.getDataType().getNum() == 2) {
						List<Transactions> tempList = new ArrayList<Transactions>();
						tran.setDataType((OperationDataType.INSERT));
						tempList.add(tran);
						tempMap.put(code, tempList);
						break;
					}
				}
			}

		}

		for (Entry<Integer, Map<String, List<Transactions>>> entry : securityCodeGroup.entrySet()) {
			Map<String, List<Transactions>> tempMap = entry.getValue();
			// ʣ��insert������
			for (Entry<String, List<Transactions>> codeEntry : tempMap.entrySet()) {
				String code = codeEntry.getKey();
				List<Transactions> codeList = codeEntry.getValue();
				for (Transactions tran : codeList) {
					if (tran.getDataType().getNum() == 1) {
						if (result.get(code) != null) {
							result.put(code, result.get(code) + tran.getQuantity() * tran.getTradeType().getFlag());
						} else {
							result.put(code, tran.getQuantity() * tran.getTradeType().getFlag());
						}
					}
				}
			}

		}
		return result;
	}
}
