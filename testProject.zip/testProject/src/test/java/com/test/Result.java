package com.test;

import java.util.Map;
import java.util.Map.Entry;

import com.sltech.com.util.CalcUtil;

import co.sltech.com.enums.OperationDataType;
import co.sltech.com.enums.OperationTradeType;
import co.sltech.com.vo.Transactions;

public class Result {

	public static void main(String[] args) {
		Transactions tran1=new Transactions(1, 1, 1, "REL",50,
				OperationDataType.INSERT, OperationTradeType.BUY);
		CalcUtil.addData(tran1);
		
		Transactions tran2=new Transactions(2, 2, 1, "ITC",40,
				OperationDataType.INSERT, OperationTradeType.SELL);
		CalcUtil.addData(tran2);
		
		Transactions tran3=new Transactions(3, 3, 1, "INF",70,
				OperationDataType.INSERT, OperationTradeType.BUY);
		CalcUtil.addData(tran3);
		
		Transactions tran4=new Transactions(4, 1, 2, "REL",60,
				OperationDataType.UPDATE, OperationTradeType.BUY);
		CalcUtil.addData(tran4);
		
		Transactions tran5=new Transactions(5, 2, 2, "ITC",30,
				OperationDataType.CANCEL, OperationTradeType.BUY);
		CalcUtil.addData(tran5);
		
		Transactions tran6=new Transactions(6, 4, 1, "INF",20,
				OperationDataType.INSERT, OperationTradeType.SELL);
		CalcUtil.addData(tran6);
		Map<String, Integer> result=CalcUtil.calcResult();
		
		for (Entry<String, Integer> entry : result.entrySet()) {
			System.out.println(entry.getKey()+":"+entry.getValue());
		}
	}

}
